let textarea = document.getElementById("textarea");
let counter = document.getElementById("counter");

textarea.addEventListener("input", function () {
  let count = textarea.value.length;
  counter.innerHTML = count + " Символов";
});

const form = document.getElementById('form');
const username = document.getElementById('textarea');

form.addEventListener('submit', e => {
  e.preventDefault();

  validateInputs();
});

const setError = (element, message) => {
  const inputControl = element.parentElement;
  const errorDisplay = inputControl.querySelector('.error');

  errorDisplay.innerText = message;
  element.classList.add('error'); // Класс ошибки для input
  element.classList.remove('success');
};

const setSuccess = element => {
  const inputControl = element.parentElement;
  const errorDisplay = inputControl.querySelector('.error');

  errorDisplay.innerText = '';
  element.classList.add('success'); // Класс успеха для input
  element.classList.remove('error');
};

const specialCharacterPattern = /[!@#$%^&*()_+?.,;'\|/'<>=-]/;

const validateInputs = () => {
  const usernameValue = username.value.trim();

  if (usernameValue === '') {
    setError(username, 'Введите логин');
   } else if (usernameValue.length < 8) {
    setError(username, 'Нужен логин больше 8 символов');
  }
  else if (!specialCharacterPattern.test(usernameValue)) {
    setError(username, 'Нужен хотя бы один спецсимвол');
  } else {
    setSuccess(username);
  }
};
